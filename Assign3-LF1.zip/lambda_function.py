from __future__ import print_function

import boto3
from decimal import Decimal
import json
import urllib

import re
import requests
from requests_aws4auth import AWS4Auth

print('Loading function')

rekognition = boto3.client('rekognition')


# --------------- Helper Functions to call Rekognition APIs ------------------


def detect_faces(bucket, key):
    response = rekognition.detect_faces(Image={"S3Object": {"Bucket": bucket, "Name": key}})
    return response


def detect_labels(bucket, key):
    response = rekognition.detect_labels(Image={"S3Object": {"Bucket": bucket, "Name": key}})

    # Sample code to write response to DynamoDB table 'MyTable' with 'PK' as Primary Key.
    # Note: role used for executing this Lambda function should have write access to the table.
    #table = boto3.resource('dynamodb').Table('MyTable')
    #labels = [{'Confidence': Decimal(str(label_prediction['Confidence'])), 'Name': label_prediction['Name']} for label_prediction in response['Labels']]
    #table.put_item(Item={'PK': key, 'Labels': labels})
    return response


def index_faces(bucket, key):
    # Note: Collection has to be created upfront. Use CreateCollection API to create a collecion.
    #rekognition.create_collection(CollectionId='BLUEPRINT_COLLECTION')
    response = rekognition.index_faces(Image={"S3Object": {"Bucket": bucket, "Name": key}}, CollectionId="BLUEPRINT_COLLECTION")
    return response


# --------------- Main handler ------------------

query_body = {
  "filtered": {
    "query": {
      "match": {}
    },
  }
}
def lambda_handler(event, context):
    
    '''Demonstrates S3 trigger that uses
    Rekognition APIs to detect faces, labels and index faces in S3 Object.
    '''
    print("Received event: " + json.dumps(event, indent=2))

    # Get the object from the event
    #print("testtesttest:::::",event['Records'][0])
    bucket = event['Records'][0]['s3']['bucket']['name']
    timestamp = event['Records'][0]['eventTime']
    key = event['Records'][0]['s3']['object']['key']
    
    #print(bucket)
    #key = urllib.unquote_plus(event['Records'][0]['s3']['object']['key'].encode('utf8'))
    #print(key)
    try:
        # Calls rekognition DetectLabels API to detect labels in S3 object
        response = detect_labels(bucket, key)
        labels=[]
        for i in range(len(response['Labels'])):
            labels.append(response['Labels'][i]['Name'])
        #print(response)
        
        picturedict={'objectKey':key,'bucket':bucket, 'createdTimestamp':timestamp, 'labels':labels}
        print(labels)
        host = 'https://vpc-assign3-es-ejrkmmfahjjw2nitoluk6o4vwq.us-east-1.es.amazonaws.com'
        index = 'index'
        type = 'index'
        headers = { "Content-Type": "application/json" }
        url = host + '/' + index + '/' + type
        credentials = boto3.Session().get_credentials()
        region = 'us-east-1'
        service = 'es'
        credentials = boto3.Session().get_credentials()
        awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, service, session_token=credentials.token)

        
        #access_key='AKIASWWX2N2OCRZOXS6C' 
        #secret_key='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'
        #awsauth = AWS4Auth(access_key, secret_key, region, service)

        r = requests.post(url, auth=awsauth, json=picturedict, headers=headers)

        #print("data:",picturedict)
        print("r is:",r)
        return response
        
    except Exception as e:
        print(e)
        print("Error processing object {} from bucket {}. ".format(key, bucket) +
              "Make sure your object and bucket exist and your bucket is in the same region as this function.")
        raise e
