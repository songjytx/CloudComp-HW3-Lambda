from elasticsearch import Elasticsearch, RequestsHttpConnection
from requests_aws4auth import AWS4Auth
import boto3
import json
host = 'https://vpc-assign3-es-ejrkmmfahjjw2nitoluk6o4vwq.us-east-1.es.amazonaws.com'
region = 'us-east-1' # e.g. us-west-1

service = 'es'
credentials = boto3.Session().get_credentials()
awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, service, session_token=credentials.token)

es = Elasticsearch(
    hosts = [{'host': host, 'port': 443}],
    http_auth = awsauth,
    use_ssl = True,
    verify_certs = True,
    connection_class = RequestsHttpConnection
)

query_body = {
  "filtered": {
    "query": {
      "match": {}
    },
    "filter": {
      "terms": {
        "tag": [],
        "minimum_should_match": 1
      }
    }
  }
}

def search(keywords):
    query_body["filtered"]["filter"]["terms"]["tag"] = keywords
    res = es.search(index="index", body = query_body)
    return res

def lambda_handler(event, context):
    # TODO implement
    userIp = event['requestContext']['identity']['sourceIp']
    body_json = json.loads(event['body'])
    print(body_json)
    content = body_json['messages'][0]['unstructured']['text']
    client = boto3.client('lex-runtime')
    response = client.post_text(
        botName='SearchImage',
        userId = 'user',
        inputText = 'I would like to search image',
        botAlias = 'Prod'
    )
    print(response)
    response = client.post_text(
        botName='SearchImage',
        userId = 'user',
        inputText = content,
        botAlias = 'Prod'
    )
    print(response)
    slotValue = response['slots'][0]['slot']
    labelArray = slotValue.split(' ')
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
