from elasticsearch import Elasticsearch, RequestsHttpConnection
from requests_aws4auth import AWS4Auth
import boto3
import json
host = 'search-photo-7bcr6wjpxwnlxcyfx2p4ovf2cm.us-east-1.es.amazonaws.com'
region = 'us-east-1' # e.g. us-west-1

service = 'es'
credentials = boto3.Session().get_credentials()
awsauth = AWS4Auth('AKIASWWX2N2OCRZOXS6C', '0cnnQmwWH3R27FXcviz+F+X5NCROnhLfR1KIRFOv', 'us-east-1', 'es')

es = Elasticsearch(
    hosts = [{'host': host, 'port': 443}],
    http_auth = awsauth,
    use_ssl = True,
    verify_certs = True,
    connection_class = RequestsHttpConnection
)
# query_body = {
#   "filtered": {
#     "query": {
#       "match": {}
#     },
#     "filter": {
#       "terms": {
#         "tag": [],
#         "minimum_should_match": 1
#       }
#     }
#   }
# }
query_body = {
    "query": { 
        "bool": {
            "minimum_should_match": 1,
            "should": [
    #   { "term": { "labels": "dog" }}
    ]
    }
    }
}
def search(keywords):
    if (len(keywords) == 0):
        return []
    
    for keyword in keywords:
        query_body['query']['bool']['should'].append({ "term": { "labels": keyword }})
    # query_body["filtered"]["filter"]["terms"]["tag"] = keywords
    res = es.search(index="index", body = query_body)
    return res['hits']['hits']

def lambda_handler(event, context):
    # TODO implement
    userIp = event['requestContext']['identity']['sourceIp']
    body_json = json.loads(event['body'])
    print(body_json)
    content = body_json['messages'][0]['unstructured']['text']
    client = boto3.client('lex-runtime')
    response = client.post_text(
        botName='SearchImage',
        userId = 'user',
        inputText = 'I would like to search image',
        botAlias = 'Prod'
    )
    print(response)
    response = client.post_text(
        botName='SearchImage',
        userId = 'user',
        inputText = content,
        botAlias = 'Prod'
    )
    print(response)
    slotValue = response['slots']['slot']
    print(slotValue)
    labelArray = slotValue.split(' ')
    print(labelArray)
    searchResult = search(labelArray)
    images = []
    for item in searchResult:
        objectKey = item['_source']['objectKey']
        bucket = item['_source']['bucket']
        images.append({'objectKey': objectKey, 'bucket': bucket})
    print(images)
    return {
        'headers': {
            'Access-Control-Allow-Origin': '*', #Required for CORS support to work
          },
        'statusCode': 200,
        'body': json.dumps(images)
    }
